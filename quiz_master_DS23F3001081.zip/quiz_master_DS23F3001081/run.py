
from flask import render_template
from config.commands import register_commands
from flask_migrate import Migrate

from app import create_app
app = create_app()


from app import db,login_manager
from app.models.user import User
migrate=Migrate(app,db)



# Blueprints
#from app.controllers.auth_controller import auth_bp
from app.controllers.users_controller import users_bp
from app.controllers.admin_controller import admin_bp


# Register Blueprints
#app.register_blueprint(auth_bp)
app.register_blueprint(users_bp)
app.register_blueprint(admin_bp)

# Register custom commands
register_commands(app)

# User loader for login_manager
@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, user_id)

# Define the home route
@app.route("/")
def home():
    return render_template("home.html")

@app.route('/login')
def login():
    return "This is the login page."

# Run the app
if __name__ == "__main__":
    app.run(debug=True)
