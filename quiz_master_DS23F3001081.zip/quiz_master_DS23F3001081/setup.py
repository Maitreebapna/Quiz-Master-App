from app import db
from app.models.user import User
from app.models.subject import Subject
from app.models.chapter import Chapter
from app.models.quiz import Quiz
from app.models.question import Question
from app.models.score import Score

from app import create_app

app = create_app()
with app.app_context():
    db.create_all()
    print(" Database tables created successfully!")
