from app import db
from datetime import datetime
from app.models.chapter import Chapter
from app.models.question import Question
from app.models.quiz import Quiz
from app.models.score import Score
from app.models.subject import Subject
from app.models.user import User

# Sample data
users_data = [
    {
        "username": "daish13@gmail.com",
        "password": "daish1303",
        "fullname": "Daisheel Bapna",
        "qualification": "B.Tech",
        "dob": datetime(2014, 3, 13)
    },
    {
        "username": "maitree.522574@gmail.com",
        "password": "06032004",
        "fullname": "Maitree Bapna",
        "qualification": "Bca",
        "dob": datetime(2004, 3, 6)
    },
    {
      "username": "user@gmail.com",
        "password": "user123",
        "fullname": "User ",
        "qualification": "B.Sc",
        "dob": datetime(1995, 11, 11)
    },
]

subjects_data = [
            {"name": "Math", "description": "Quiz related to math."},
            {"name": "General Knowledge", "description": "Quiz related to general knowledge."},
            {"name": "Python", "description": "Quiz related to Python."}
        ]

chapters_data = [
            {"name": "Algebra", "description": "Basics of algebra.", "subject_id": 1},
            {"name": "Geometry", "description": "Basics of geometry.", "subject_id": 1},
            {"name": "Current Affairs", "description": "Test your knowledge of current affairs.", "subject_id": 2},
            {"name": "Indian History", "description": "Test your knowledge of indian history.", "subject_id": 2},
            {"name": "Python", "description": "Basics of python.", "subject_id": 3}
        ]

quizzes_data = [
            {"title":"Math Quiz","name": "Algebra Basics", "date_of_quiz": datetime(2025, 4, 1), "time_duration": 10*60, "chapter_id": 1},
            {"title":"Math Quiz","name": "Geometry Basics", "date_of_quiz": datetime(2025, 4, 2), "time_duration": 10*60, "chapter_id": 2},
            {"title":"General Knowledge Quiz","name": "Current Affairs Basics", "date_of_quiz": datetime(2025, 4, 3), "time_duration": 10*60, "chapter_id": 3},
            {"title":"General Knowledge Quiz","name": "Indian History Basics", "date_of_quiz": datetime(2025, 4, 3), "time_duration": 10*60, "chapter_id": 4},
            {"title":"Python Quiz","name": "Python Basics", "date_of_quiz": datetime(2025, 4, 1), "time_duration": 10*60, "chapter_id": 5}
        ]

questions_data = [
    # Questions for Quiz 1: Algebra Basics
    {
        "question_statement": "What is 16+2-8?",
        "option1": "20",
        "option2": "10",
        "option3": "5",
        "option4": "16",
        "correct_option": 2,
        "quiz_id": 1
    },
    {
        "question_statement": "What is 23 * 5?",
        "option1": "230",
        "option2": "15",
        "option3": "115",
        "option4": "25",
        "correct_option": 3,
        "quiz_id": 1
    },
   

    # Questions for Quiz 2: Geometry Basics
    {
        "question_statement": "What is the sum of angles in a triangle?",
        "option1": "90 degrees",
        "option2": "180 degrees",
        "option3": "270 degrees",
        "option4": "360 degrees",
        "correct_option": 2,
        "quiz_id": 2
    },
    {
        "question_statement": "What is the area of a square with side length 2?",
        "option1": "8",
        "option2": "2",
        "option3": "4",
        "option4": "20",
        "correct_option": 3,
        "quiz_id": 2
    },

    # Questions for Quiz 3: Current Affairs Basics
    {
        "question_statement": "What is the capital of Germany ?",
        "option1": "Scotland",
        "option2": "Berlin",
        "option3": "rome",
        "option4": "Pascal",
        "correct_option": 2,
        "quiz_id": 3
    },
    {
        "question_statement": "What is the folk dance of Bihar?",
        "option1": "Jhijhiya",
        "option2": "Ghoomar",
        "option3": "Bihu",
        "option4": "Garba",
        "correct_option": 1,
        "quiz_id": 3
    },

    # Questions for Quiz 4: Indian History Basics
    {
        "question_statement": "The Battle of Plassey was fought in?",
        "option1": "1757",
        "option2": "1782",
        "option3": "1748",
        "option4": "1764",
        "correct_option": 1,
        "quiz_id": 4
    },
    {
        "question_statement": "Ramayana was written by?",
        "option1": "Ved Vyasa",
        "option2": "Valmiki",
        "option3": "Tulsidas",
        "option4": "Hanumanji",
        "correct_option": 2,
        "quiz_id": 4
    },

    # Questions for Quiz 5: Python Basics
    {
        "question_statement": "What type of programming language is Python?",
        "option1": "Compiled",
        "option2": "Interpreted",
        "option3": "both",
        "option4": "None",
        "correct_option": 2,
        "quiz_id": 5
    },
    {
        "question_statement":" Which of the following is NOT a built-in data type in Python?",
        "option1": "List",
        "option2": "Tuple",
        "option3": "Array",
        "option4": "Dictionary",
        "correct_option": 3,
        "quiz_id": 5
    },

]

attempts_data = [
    {"user_id": 1, "quiz_id": 1, "total_scored": 8},
    {"user_id": 2, "quiz_id": 2, "total_scored": 9},
    {"user_id": 3, "quiz_id": 3, "total_scored": 6},
    {"user_id": 4, "quiz_id": 4, "total_scored": 7},
    {"user_id": 1, "quiz_id": 5, "total_scored": 8},
    {"user_id": 4, "quiz_id": 2, "total_scored": 4},
    
]

def seed_database():
    # Add users
    for user_data in users_data:
        user = User(
            username=user_data["username"],
            fullname=user_data["fullname"],
            qualification=user_data["qualification"],
            dob=user_data["dob"]
        )
        user.set_password(user_data["password"])
        db.session.add(user)
    
    # Add subjects
    for subject_data in subjects_data:
        subject = Subject(
            name=subject_data["name"],
            description=subject_data["description"]
        )
        db.session.add(subject)
    
    # Add chapters
    for chapter_data in chapters_data:
        chapter = Chapter(
            name=chapter_data["name"],
            description=chapter_data["description"],
            subject_id=chapter_data["subject_id"]
        )
        db.session.add(chapter)
    
    # Add quizzes
    for quiz_data in quizzes_data:
        quiz = Quiz(
            name=quiz_data["name"],
            date_of_quiz=quiz_data["date_of_quiz"],
            time_duration=quiz_data["time_duration"],
            chapter_id=quiz_data["chapter_id"]
        )
        db.session.add(quiz)
    
    # Add questions
    for question_data in questions_data:
        question = Question(
            question_statement=question_data["question_statement"],
            option1=question_data["option1"],
            option2=question_data["option2"],
            option3=question_data["option3"],
            option4=question_data["option4"],
            correct_option=question_data["correct_option"],
            quiz_id=question_data["quiz_id"]
        )
        db.session.add(question)
    
    # Add attempts
    for attempt_data in attempts_data:
        attempt = Score(
            user_id=attempt_data["user_id"],
            quiz_id=attempt_data["quiz_id"],
            total_scored=attempt_data["total_scored"]
        )
        db.session.add(attempt)
    
    db.session.commit()
