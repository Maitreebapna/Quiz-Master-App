from app import db
from .base import BaseModel

class Attempt(BaseModel):
    __tablename__ = 'attempts'
    
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    quiz_id = db.Column(db.Integer, db.ForeignKey('quizzes.id'), nullable=False)
    total_scored = db.Column(db.Integer, nullable=False)

    def __repr__(self):
        return f'<Attempt User: {self.user_id}, Quiz: {self.quiz_id}, Score: {self.total_scored}>'
