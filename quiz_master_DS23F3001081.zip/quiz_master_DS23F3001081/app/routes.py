from flask import Blueprint, render_template, redirect, url_for, flash, request , current_app
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from app.forms import LoginForm,ChapterForm , SubjectForm , QuizForm , QuestionForm
from app.models.subject import Subject
from app.models.chapter import Chapter
from app.models.quiz import Quiz
from app.models.question import Question
from app.models.score import Score
from app.models.user import User 
from app import db 
import os 

routes_bp = Blueprint('routes_bp', __name__) 


def get_admin_user():
    from app.models.user import User
    with current_app.app_context():
        print("Checking if admin exists...")
        admin = User.query.filter_by(username="admin@quiz.com").first()
        if not admin:
            print("Admin not found, creating now...")
            admin = User(
                username="admin@gmail.com",
                fullname="Admin",
                qualification="Admin Role",  # Add a default qualification
                dob="2000-01-01",  # Provide a valid date format
                is_admin=True
            )
            admin.set_password("admin1234")
            db.session.add(admin)
            db.session.commit()
            print(" Admin created successfully!")
        else:
            print(" Admin already exists!")



@routes_bp.route("/")
def home():
    return render_template("home.html")

@routes_bp.route("/admin/login", methods=['GET','POST'])
def admin_login():
    from app.models.user import User 
    form=LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.email.data).first()
        if user and user.check_password(form.password.data):
            login_user(user)
            flash("Admin logged in successfully!")
            return redirect(url_for("routes.admin_dashboard"))
        else:
            flash("Invalid Email or Password")
    return render_template("admin/login.html", form=form)

@routes_bp.route("/admin/dashboard")
@login_required
def admin_dashboard():
    if current_user.username != "admin@quiz.com":
        flash("Unauthorized access!")
        return redirect(url_for("routes.home"))
    quizzes = Quiz.query.all()
    quiz_names = [ quiz.name for quiz in quizzes]
    average_scores = []
    completion_rates = []

    for quiz in quizzes:
        scores = Score.query. filter_by(quiz_id = quiz.id).all()
        if scores:
            average_score = sum([s.total_scored for s in scores]) / len(scores)

            users_attempted = len(scores)
            completion_rate = (users_attempted / (User.query.count() - 1)) * 100
        else:
            average_score = 0
            completion_rate = 0
        average_scores.append(average_score)
        completion_rate.append(completion_rate)        
    return render_template("admin/dashboard.html",
                           quiz_names=quiz_names,
                           average_scores=average_scores,
                           completion_rates=completion_rates)
    

@routes_bp.route('/admin/manage_subjects')
@login_required 
def manage_subjects():
    if current_user.username !="admin@quiz.com":
        flash("You don't have permission to access this page",)
        return redirect(url_for("routes.home"))
    subjects = Subject.query.all()
    return render_template('admin/manage_subjects.html', subjects=subjects)


@routes_bp.route("/admin/add_subject", methods=['GET','POST'])
@login_required
def add_subject():
    if current_user.username !="admin@quiz.com":
        flash("You don't have permission to access this page",)
        return redirect(url_for("routes.home"))
    form = SubjectForm()
    if form.validate_on_submit():
        subject = Subject(name=form.name.data, description=form.description.data) 
        db.session.add(subject)
        db.session.commit()
        flash("Subject added successfully!")
        return redirect(url_for("routes.manage_subjects")) 
    return render_template("admin/add_subject.html", form=form)  

@routes_bp.route("/admin/edit_subject/<int:subject_id>",methods=['GET','POST'])
@login_required
def edit_subject(subject_id):
    print("Current User:" , current_user.username)
    print("Admin Username from.env:" , os.getenv('ADMIN_USERNAME'))

    if current_user.username !=os.getenv('ADMIN_USERNAME'):
        flash("You don't have permission to access this page")
        return redirect(url_for("routes.home"))
    
    subject = Subject.query.get_or_404(subject_id)
    form = SubjectForm(obj=subject)

    if form.validate_on_submit():
        subject.name = form.name.data
        subject.description = form.description.data
        db.session.commit()
        flash("Subject updated successfully !")
        return redirect(url_for("routes.admin_manage_subjects"))
    return render_template("admin/edit_subject.html",form=form)

@routes_bp.route("/admin/delete_subject/<int:subject_id>",methods=['POST'])
@login_required
def delete_subject(subject_id):
    if current_user.username != os.getenv('ADMIN_USERNAME'):
        flash("You don't have permission to access this page")
        return redirect(url_for("routes.home"))
    subject = Subject.query.get_or_404(subject_id)
    db.session.delete(subject)
    db.session.commit()
    flash("Subject deleted successfully !")
    return redirect(url_for("routes.manage_subjects"))

@routes_bp.route('/admin/manage_chapters', endpoint='admin_manage_chapters')
@login_required 
def manage_chapters():
    if current_user.username !="admin@quiz.com":
        flash("You don't have permission to access this page",)
        return redirect(url_for("home"))
    chapters = Chapter.query.all()
    return render_template('admin/manage_chapters.html', chapters=chapters)


@routes_bp.route("/admin/add_chapter", methods=['GET','POST'])
@login_required
def add_chapter():
    if current_user.username !="admin@quiz.com":
        flash("You don't have permission to access this page",)
        return redirect(url_for("home"))
    form = ChapterForm()
    form.subject_id.choices = [(subject.id,subject.name) for subject in Subject.query.all()]

    if form.validate_on_submit():
        new_chapter = Chapter(
            name=form.name.data, 
            description=form.description.data,
            subject_id=form.subject_id.data
        )     
        db.session.add(new_chapter)
        db.session.commit()
        flash("Chapter added successfully!")
        return redirect(url_for("routes.admin_dashboard")) 
    return render_template("admin/add_chapter.html", form=form) 

@routes_bp.route("/admin/edit_chapter/<int:chapter_id>",methods=['GET','POST'])
@login_required
def edit_chapter(chapter_id):
    if current_user.username != os.getenv('ADMIN_USERNAME'):
        flash("You don't have permission to access this page")
        return redirect(url_for("routes.home"))
    chapter = Chapter.query.get_or_404(chapter_id)
    form = ChapterForm(obj=chapter)
    form.subject_id.choices = [(s.id,s.name) for s in Subject.query.all()]
    if form.validate_on_submit():
        chapter.name = form.name.data
        chapter.description = form.description.data
        chapter.subject_id = form.subject_id.data 
        db.session.commit()
        flash("Chapter updated successfully !")
        return redirect(url_for("routes.admin_manage_chapters"))
    return render_template("admin/edit_chapter.html",form=form)

@routes_bp.route("/admin/delete_chapter/<int:chapter_id>",methods=['GET','POST'])
@login_required
def delete_chapter(chapter_id):
    if current_user.username != os.getenv('ADMIN_USERNAME'):
        flash("You don't have permission to access this page")
        return redirect(url_for("routes.home"))
    chapter = Chapter.query.get_or_404(chapter_id)
    db.session.delete(chapter)
    db.session.commit()
    flash("Chapter deleted successfully !")
    return redirect(url_for("manage_chapters"))

@routes_bp.route('/admin/manage_quizzes', endpoint='admin_manage_quizzes')
@login_required 
def manage_quizzes():
    if current_user.username !="admin@quiz.com":
        flash("You don't have permission to access this page",)
        return redirect(url_for("home"))
    quizzes = Quiz.query.all()
    return render_template('admin/manage_quizzes.html', quizzes=quizzes)

@routes_bp.route("/admin/add_quiz", methods=['GET','POST'])
@login_required
def add_quiz():
    if current_user.username !="admin@quiz.com":
        flash("You don't have permission to access this page",)
        return redirect(url_for("home"))
    form = QuizForm()
    form.chapter_id.choices = [(c.id,c.name) for c in Chapter.query.all()]
    if form.validate_on_submit():
        quiz = Quiz(
            date_of_quiz = form.date_of_quiz.data,
            time_duration = form.time_duration.data,
            chapter_id = form.chapter_id.data
        ) 
        db.session.add(quiz)
        db.session.commit()
        flash("Quiz added successfully!")
        return redirect(url_for("manage_quizzes")) 
    return render_template("admin/add_quiz.html", form=form) 

@routes_bp.route("/admin/edit_quiz/<int:id>",methods=['GET','POST'])
@login_required
def edit_quiz(id):
    if current_user.username != os.getenv('ADMIN_USERNAME'):
        flash("You don't have permission to access this page")
        return redirect(url_for("routes.home"))
    quiz = Quiz.query.get_or_404(id)
    form = QuizForm(obj=quiz)
    form.chapter_id.choices = [(c.id,c.name) for c in Chapter.query.all()]
    if form.validate_on_submit():
        quiz.date_of_quiz = form.date_of_quiz.data
        quiz.time_duration = form.time_duration.data
        quiz.chapter_id = form.chapter_id.data
        db.session.commit()
        flash("Quiz updated successfully !")
        return redirect(url_for("routes.admin_manage_quizzes"))
    return render_template("admin/edit_quiz.html",form=form)

@routes_bp.route("/admin/delete_quiz/<int:id>",methods=['GET','POST'])
@login_required
def delete_quiz(id):
    if current_user.username != os.getenv('ADMIN_USERNAME'):
        flash("You don't have permission to access this page")
        return redirect(url_for("routes.home"))
    quiz = Quiz.query.get_or_404(id)
    db.session.delete(quiz)
    db.session.commit()
    flash("Quiz deleted successfully !")
    return redirect(url_for("manage_quizzes"))


@routes_bp.route('/admin/manage_quiz_questions/<int:quiz_id>', endpoint='admin_manage_quiz_questions')
@login_required 
def admin_manage_quiz_questions(quiz_id):
    if current_user.username !="admin@quiz.com":
        flash("You don't have permission to access this page",)
        return redirect(url_for("routes.home"))
    quiz= Quiz.query.get_or_404(quiz_id)
    questions = Question.query.filter_by(quiz_id=quiz_id).all()
    return render_template('admin/manage_quiz_questions.html', quiz=quiz ,questions=questions)

@routes_bp.route("/admin/add_question/<int:quiz_id>",methods=['GET','POST'])
@login_required
def add_question(quiz_id):
    if current_user.username !="admin@quiz.com":
        flash("You don't have permission to access this page",)
        return redirect(url_for("routes.home"))
    form = QuestionForm()
    if form.validate_on_submit():
        new_question = Question(
            question_statement = form.question_statement.data,
            option1=form.option1.data,
            option2=form.option2.data,
            option3=form.option3.data,
            option4=form.option4.data,
            correct_option = form.correct_option.data,
            quiz_id=quiz_id
        )
        db.session.add(new_question)
        db.session.commit()
        flash("Question added successfully!")
        return redirect( url_for("routes.admin_manage_quiz_questions",quiz_id=quiz_id))
    return render_template("admin/add_question.html", form=form,quiz_id=quiz_id)

@routes_bp.route("/admin/delete_question/<int:question_id>", methods=['POST'])
@login_required
def delete_question(question_id):
    if current_user.username != "admin@quiz.com":
        flash("You don't have permission to access this page")
        return redirect(url_for("routes.home"))

    question = Question.query.get_or_404(question_id)
    quiz_id = question.quiz_id
    db.session.delete(question)
    db.session.commit()
    flash("Question deleted successfully!")
    return redirect(url_for("routes.admin_manage_quiz_questions", quiz_id=quiz_id))


@routes_bp.route('/admin/manage_users', endpoint='admin_manage_users')
@login_required 
def manage_users():
    if current_user.username !="admin@quiz.com":
        flash("You don't have permission to access this page",)
        return redirect(url_for("home"))
    users = User.query.all()
    return render_template('admin/manage_users.html', users=users)

@routes_bp.route("/admin/manage_scores", endpoint='admin_manage_scores')
@login_required
def manage_scores():
    if current_user.username !="admin@quiz.com":
        flash("You don't have permission to access this page",)
        return redirect(url_for("home"))
    scores = Score.query.all()
    return render_template("admin/manage_scores.html",scores=scores)


@routes_bp.route("/register" , methods=['GET','POST'])
def register(): 
    from app.models.user import User  
    from app.forms import RegisterForm

    form = RegisterForm()
    if form.validate_on_submit():
        new_user = User(
            username=form.username.data,
            email = form.email.data,
            fullname=form.fullname.data,
            qualification=form.qualification.data,
            dob=form.dob.data
        )
        new_user.set_password(form.password.data)
        db.session.add(new_user)
        db.session.commit()
        flash('Account created successfully!')
        return redirect(url_for('routes.login'))
    return render_template("register.html", form=form)
    


@routes_bp.route("/login" , methods=['GET','POST'])
def login():
    from app.models.user import User 

    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        if user and  user.check_password(form.password.data):
            login_user(user)
            flash('Login successfull !')
            return redirect(url_for('routes.dashboard'))
        else:
            flash("Invalid username or password !")
    return render_template("login.html", form=form)



@routes_bp.route("/dashboard")
@login_required 
def dashboard():
    quizzes = Quiz.query.all()
    return render_template("dashboard.html", quizzes=quizzes)

@routes_bp.route("/quiz/<int:quiz_id>" , methods=['GET','POST'])
@login_required
def attempt_quiz(quiz_id):
    quiz = Quiz.query.get_or_404(quiz_id)
    questions = quiz.questions
    if request.method=='POST':
        score = 0
        for question in questions:
            user_answer = request.form.get(f"question_{question.id}")
            if user_answer and int(user_answer) == question.correct_option:
                score+=1
        user_score = Score(
            total_scored = score,
            quiz_id=quiz_id,
            user_id=current_user.id
        )   
        db.session.add(user_score)
        db.session.commit()
        flash(f"Your score:{score}/ {len(questions)}")
        return redirect(url_for("routes.quiz_results",quiz_id=quiz_id))     
    return render_template('attempt_quiz.html',quiz=quiz,questions=questions)

@routes_bp.route("/quiz_results/<int:quiz_id>")
@login_required
def quiz_results(quiz_id):
    quiz=Quiz.query.get_or404(quiz_id)
    score = Score.query.filter_by(user_id=current_user.id,quiz_id=quiz_id).first()
    return render_template("quiz_results.html",quiz=quiz,score=score)


@routes_bp.route("/logout")
@login_required
def logout():
    logout_user()
    flash('Logout successfull !')
    return redirect(url_for('routes.login'))

'''if __name__ == "__main__":
    app.run(debug=True) '''








